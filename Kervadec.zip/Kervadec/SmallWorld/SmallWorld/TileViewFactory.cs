﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmallWorld
{
    public class TileViewManager
    {
        public TileViewManager()
        {
            throw new System.NotImplementedException();
        }
    
        public TileView getTileView(TileType t, int typeId)
        {
            throw new System.NotImplementedException();
        }
    }
}
