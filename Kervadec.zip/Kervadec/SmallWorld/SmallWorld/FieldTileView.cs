﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmallWorld
{
    public class FieldTileView1 : TileView
    {
    }

    public class MoutainTileView1 : TileView
    {
    }

    public class ForestTileView1: TileView
    {
    }

    public class DesertTileView1 : TileView
    {
    }
}
