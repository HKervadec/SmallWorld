﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmallWorld
{
    public class Strategy : GameStrategy
    {
    }

    public class StrategyNormal : GameStrategy
    {
    }

    public class StrategyHuge : GameStrategy
    {
    }
}
