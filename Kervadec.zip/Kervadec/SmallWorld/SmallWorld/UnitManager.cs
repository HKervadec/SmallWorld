﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SmallWorld
{
    public class UnitManager
    {

        public void bagarre(Coord attacker, Coord defender)
        {
            throw new System.NotImplementedException();
        }
    }
}
